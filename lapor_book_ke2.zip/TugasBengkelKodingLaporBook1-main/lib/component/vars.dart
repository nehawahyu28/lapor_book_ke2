import 'package:flutter/material.dart';
import 'package:flutter_lapor_book/component/styles.dart';

List<String> dataStatus = ['Posted', 'Proses', 'Selesai'];
List<Color> warnaStatus = [warningColor, dangerColor, successColor];
List<String> dataInstansi = ['Pembangunan', 'Jalanan', 'Pendidikan'];
